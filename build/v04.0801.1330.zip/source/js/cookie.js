/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-06-26 21:41:15
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xue.cookie.js
 * @description 操作cookie
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

xue.cookie = xue.cookie || function( key, val){

};
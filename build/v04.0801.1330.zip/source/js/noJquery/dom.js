/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-06-26 21:41:15
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xue.dom.js
 * @description DOM操作
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

xue.dom = xue.dom || function(selector, context){ return this; };
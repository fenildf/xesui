/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:58:15
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.avatar.js
 * @description 用户头像部分（老师切换等）
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 17:15:00
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.carousel.js
 * @description 图片轮播
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


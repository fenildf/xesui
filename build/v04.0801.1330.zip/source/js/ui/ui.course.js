/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:48:18
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.courses.js
 * @description 这里是课程列表的全部交互效果
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


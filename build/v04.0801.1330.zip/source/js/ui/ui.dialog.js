/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:52:54
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.dialog.js
 * @description 全站弹窗
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:47:25
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.feed.js
 * @description 这里是动态的全部交互
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


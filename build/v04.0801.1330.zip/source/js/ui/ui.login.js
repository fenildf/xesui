/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:52:09
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.login.js
 * @description 用户登录注册交互
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


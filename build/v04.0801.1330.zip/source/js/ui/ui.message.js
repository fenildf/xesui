/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 17:01:57
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.message.js
 * @description 信息
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


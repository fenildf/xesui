/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 17:16:00
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.nav.js
 * @description 导航组件
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


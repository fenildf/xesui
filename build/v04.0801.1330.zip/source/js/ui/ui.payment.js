/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 16:55:41
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.payment.js
 * @description 支付相关
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 17:13:57
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.preview.js
 * @description 预览组件
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


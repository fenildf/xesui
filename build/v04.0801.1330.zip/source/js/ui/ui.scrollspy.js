/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-08 17:14:35
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name ui.scrollspy.js
 * @description 滚动监听
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


<?php
/**
 *      
 * @authors Marco (marco@xesui.com)
 * @date    2013-07-21 09:54:11
 * @version $Id$
 */

$callback = array('sign' => 1, 'msg' => 'ok');

echo json_encode($callback);

?>
<?php $ID = $_POST['dynId']; 

echo "<div>.......... ID: ".$ID." ........</div>";



$tpl = '<div class="comment_list"><div class="ui_avatar avatar_mini"><a href="##" class="userpic J_userinfo"><img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a></div><div class="feed_detail"><div class="feed_text"><strong>小明：</strong>秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二</div><div class="feed_bar"><span><i class="S_time">5小时前</i></span></div></div></div>';
$more = '<!--评论 repeat --><div class="comment_more"><a href="'.$ID.'">点击查看更多评论</a></div>';

$n = 5;

if ($ID == 1) {
	$n  = 10;
}elseif ($ID == 2) {
	$n = 5;
}else{
	$n = 3;
}

$html ='';

for($i = 0; $i < $n; $i++){
	if($i < 5){
		$html .= $tpl;
	}
}
if($n > 5){
	$html .= $more;
}
echo $html;
?>
<!-- <div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>
<div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>

<div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>

<div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>

<div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>



<div class="comment_list">
	<div class="ui_avatar avatar_mini">
		<a href="##" class="userpic J_userinfo">
			<img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
	</div>
	<div class="feed_detail">
		<div class="feed_text">
			<strong>小明：</strong>
			秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二秀情老师数学加油站系列讲座第十二
		</div>

		<div class="feed_bar">
			<span>
				<i class="S_time">5小时前</i>
			</span>
		</div>
	</div>
</div>


 -->

<!--评论 repeat -->
<!-- <div class="comment_more">
	<a href="#">点击查看更多评论</a>
</div> -->
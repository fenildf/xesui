<?php
/**
 * 
 * @authors Marco (marco@xesui.com)
 * @date    2013-07-24 12:54:16
 * @version $Id$
 */

$tp = $_POST['type'];
$title = '';
switch ($tp) {
    case '1':
        $title = '系统通知：';
        break;
    case '2':
        $title = '资料提醒：';
        break;
    case '3':
        $title = '直播提醒：';
        break;
    case '4':
        $title = '教师留言：';
        break;
    case '5':
        $title = '月考提醒：';
        break;
    default:
        $title = '系统通知：';
        break;
}
$html = '<div class="inform_item"><div class="inform_con"><span class="title">' . $title . '</span><span class="text"><a href="#">王雨洁</a>新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我们，反馈信息，谢谢同学们</span></div><div class="inform_time">5天前<a href="#">删除</a></div></div>';

echo $html;


?>

<!-- 
<div class="inform_item">
        <div class="inform_con">
            <span class="title">系统通知：</span>
            <span class="text">
                <a href="#">王雨洁</a>
                新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们
            </span>
        </div>
        <div class="inform_time">
            5天前
            <a href="#">删除</a>
        </div>
</div>
<div class="inform_item">
        <div class="inform_con">
            <span class="title">教师留言：</span>
            <span class="text">
                <a href="#">王雨洁</a>
                新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们
            </span>
        </div>
        <div class="inform_time">
            5天前
            <a href="#">删除</a>
        </div>
</div>
<div class="inform_item">
        <div class="inform_con">
            <span class="title">直播提醒：</span>
            <span class="text">
                <a href="#">王雨洁</a>
                新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们
            </span>
        </div>
        <div class="inform_time">
            5天前
            <a href="#">删除</a>
        </div>
</div>
<div class="inform_item">
        <div class="inform_con">
            <span class="title">月考提醒：</span>
            <span class="text">
                <a href="#">王雨洁</a>
                新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们
            </span>
        </div>
        <div class="inform_time">
            5天前
            <a href="#">删除</a>
        </div>
</div>
<div class="inform_item">
        <div class="inform_con">
            <span class="title">资料提醒：</span>
            <span class="text">
                <a href="#">王雨洁</a>
                新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们新版学习中心即将上线，请各位同学及时关注，关通知我我们，反馈信息，谢谢同学们
            </span>
        </div>
        <div class="inform_time">
            5天前
            <a href="#">删除</a>
        </div>
</div> -->
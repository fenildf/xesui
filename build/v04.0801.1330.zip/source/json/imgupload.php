<?php
/**
 * 
 * @authors Marco (marco@xesui.com)
 * @date    2013-07-23 19:10:04
 * @version $Id$
 */


// $con = $_POST['content'];
// $img = $_POST['dynImg'];
// // $con = $_POST['content'];
// // $con = $_POST['content'];

// echo $img;
// return json_encode('ok');


$file_path = '../uploads/';
$img = $_FILES['dynImg'];

$file_up = $file_path.basename($img['name']);
echo $file_up;
exit;
if(move_uploaded_file($img['tmp_name'],$file_up)){
    echo 'success'; 
}else{
    echo 'fail';    
}




// $img = $_FILES['dynImg'];

return json_encode($img);


$error = ""; //上传文件出错信息
$msg = "";
$fileElementName = 'dynImg';
    $allowType = array(".jpg",".gif",".png"); //允许上传的文件类型
    $num      = strrpos($_FILES['dynImg']['name'] ,'.');  
$fileSuffixName    = substr($_FILES['dynImg']['name'],$num,8);//此数可变  
$fileSuffixName    = strtolower($fileSuffixName); //确定上传文件的类型

$upFilePath             = '../upload'; //最终存放路径
if(!empty($_FILES[$fileElementName]['error']))
{
   switch($_FILES[$fileElementName]['error'])
   {
    case '1':
     $error = '传的文件超过了 php.ini 中 upload_max_filesize 选项限制的值';
     break;
    case '2':
     $error = '上传文件的大小超过了 HTML 表单中 MAX_FILE_SIZE 选项指定的值';
     break;
    case '3':
     $error = '文件只有部分被上传';
     break;
    case '4':
     $error = '没有文件被上传';
     break;
    case '6':
     $error = '找不到临时文件夹';
     break;
    case '7':
     $error = '文件写入失败';
     break;
    default:
     $error = '未知错误';
   }
    return json_encode($error);

}elseif(empty($_FILES['fileToUpload']['tmp_name']) || $_FILES['fileToUpload']['tmp_name'] == 'none')
{
   $error = '没有上传文件.';
    return json_encode($error);
}else if(!in_array($fileSuffixName,$allowType))
{
   $error = '不允许上传的文件类型'; 
    return json_encode($error);
}else{
  $ok=@move_uploaded_file($_FILES['fileToUpload']['tmp_name'],$upFilePath );
   if($ok === FALSE){
    $error = '上传失败';
    return json_encode($error);
   }
}

?>
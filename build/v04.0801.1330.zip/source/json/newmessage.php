<?php
/**
 * 
 * @authors Marco (marco@xesui.com)
 * @date    2013-07-24 11:51:13
 * @version $Id$
 */


$callback = array('sign' => 1, 'msg' => 'ok');

echo json_encode($callback);








?>
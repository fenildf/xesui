<?php

$id = $_POST['uid'];

if($id > 3){
    return '没有找到该用户';
}






if($id == 1){
?>
<div class="pop_userinfo">
    <div class="ui_avatar">
        <a href="##" class="userpic"><img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
    </div>
    <div class="userinfo_follow">
        <a href="" class="ui_username">王雨洁<i class="icon icon_yverify">V</i></a>
        <p class="fun_usres">小学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级学六年级语文小学六年级语文小学六年级语文小学六年级学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级语文小学六年级语文</p>
        <p class="user_statistics">
            <strong class="f_red">543</strong>学员
            <i class="line">|</i>
            <strong class="f_red">43</strong>课程
        </p>
        <div class="ui_follow add"> <em>+</em> 关注 </div>
    </div>
</div>
<?php }elseif($id == 2){ ?>
<div class="pop_userinfo">
    <div class="ui_avatar">
        <a href="##" class="userpic"><img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
    </div>
    <div class="userinfo_follow">
        <a href="" class="ui_username">王雨洁 <i class="icon icon_yverify">V</i></a>
        <p class="fun_usres">小学六年级语文</p>
        <p class="user_statistics"> <strong class="f_red">543</strong>学员 <i class="line">|</i> <strong class="f_red">43</strong>课程
        </p>
        <div class="ui_follow follow_cancel"> <em class="addsucess"></em>已关注<i class="line">|</i><a href="#" class="btn_cancel">取消</a></div>
    </div>
</div>

<?php }elseif($id == 3){?>
<div class="pop_userinfo">
<div class="ui_avatar">
    <a href="##" class="userpic">
        <img src="http://file.xueersi.com/web/13105601335455.jpg" alt="" width="60" height="60"></a>
</div>
<div class="userinfo_follow">

    <a href="" class="ui_username">
        王雨洁 <i class="icon icon_yverify">V</i>
    </a>
    <p class="fun_usres">小学六年级语文</p>
    <p class="user_statistics"> <strong class="f_red">543</strong>
        学员 <i class="line">|</i> <strong class="f_red">43</strong>
        课程
    </p>
    <div class="ui_follow follow_cancel"> <em class="addsucess"></em>
        已关注
        <i class="line">|</i>
        <a href="#" class="btn_cancel">取消</a>
    </div>
</div>
</div>
<?php }?>
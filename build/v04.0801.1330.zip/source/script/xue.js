/*
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-06-26 21:21:50
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xesui.js
 * @description 声明 xue 包：增加别名“X”
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

var X, xue = X = xue || function(expr, fn) { return xue.dom ? xue.dom(expr, fn) : {}; };
// var X, xue = X = xue || function(expr, fn) { 
// 	xue.expr = expr || null;
// 	return xue;
// };

xue.version = '0.4.7';

xue.id = 'xesui';
xue.guid = '$XESUI$';
xue.team = {
	Marco  : 'Marco@xesui.com',
	Alex   : 'Alex@xesui.com',
	Sam    : 'Sam@xesui.com',
	Star   : 'W.Star@xesui.com'
}

xue.expr = '';
/* ========================== 公共方法 =========================== */

xue.random = function(min, max, len){};

/**
 * 返回时间数
 * @param  {Date} date 指定日期 2012-05-23
 * @return {number}      返回以毫秒为单位的时间
 */
xue.getTime = function(date){
	var d = date ? new Date(date) : new Date;
	return d.getTime();
};
/**
 * @name xue.extend.js
 * @description 扩展
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

xue.extend = xue.extend || function(className, fn, constructor){
	var _name = className;

	var _class = xue[_name] = xue[_name] || fn;

	// return _class;
	return this;
};

xue.ajaxCheck = xue.ajaxCheck || {};


xue.ajaxCheck.HTML = function( str ){
	if(!str){ 
		xue.alert('数据读取错误……');
		return false; 
	}
	var str = $.trim(str);
	if(str.substr(0,1)=='<'){
		return str;
	}else if(str.substr(0,4)=='http' || str.substr(0,1)=='/'){
		window.location.href = str;
		return false;
	}else{
		// if(str.substr(0,6) == 'error:'){
			xue.alert(str);
			return false;
		// }
		// xue.alert(str);
		// return str;
	}



	// if(str.substr(0,6) == 'error:'){
	// 	xue.alert(str);
	// 	return false;
	// }else if(str.substr(0,4)=='http' || str.substr(0,1)=='/'){
	// 	window.location.href = str;
	// 	return false;
	// }else{
	// 	return str;
	// }
};

xue.ajaxCheck.JSON = function( d ){
	if(!d){ 
		xue.alert('数据读取错误……');
		return false; 
	}
	var tp = d.sign, msg = d.msg;
	if(tp === 0){
		xue.alert(msg);
		return false;
	}
	if(tp === 2){
		window.location.href = d.msg;
	}
	if(tp === 1){
		return msg;
	}
};

xue.ajaxCheck.json = xue.ajaxCheck.JSON;
xue.ajaxCheck.html = xue.ajaxCheck.HTML;

// xue.check = function(obj){

	// 还差日期类型判断
	
	// if(typeof obj === 'object' && typeof(obj.length) === 'number'){
	// 	return 'array';
	// }
	// if(typeof obj === 'string' && typeof(obj.length) === 'number'){
	// 	return 'string';
	// }
	// if(typeof obj === 'function' && typeof(obj.length) === 'number'){
	// 	return 'function';
	// }
	// if(typeof obj === 'number' && typeof(obj.length) === 'undefined'){
	// 	return 'number';
	// 	// 还差日期类型判断 return 'date'
	// }
	// if(typeof obj === 'object' && typeof(obj.length) === 'undefined'){
	// 	return '{}';
	// }
	
// };

/**
 * 异步加载JS/CSS文件
 * @param  {[type]}   url [description]
 * @param  {Function} fn  [description]
 * @return {[type]}       [description]
 */
xue.load = xue.load || function( url, fn ){
	if(!url){ return xue; }
	
	var tp = xue.load._checkType(url);
	var callback = null;

	$.each(arguments, function(){
		if(typeof this == 'function'){
			callback = this;
		}else{
			return this;
		}
	});

	xue.load.callback = callback;

	if(xue.load.isExist(url)){
		// xue.alert('文件已存在');
		if(callback){
			callback();
		}
		return xue;
	}
	if(tp){
		xue.load[tp](url);
	}

	return xue;
};

(function(){

	var load = xue.load;

	load.files = {};

	// 回调函数
	load.callback = null;
	load.type = null;
	load.url = null;

	// 加载外部js文件
	load.js = function( url ){
	
		var _call = load.callback ? load.callback : function(){};

		// 检测文件是否存在，不存在则加载，否则直接返回callback
		if(!this.isExist(url)) {
			var file = document.createElement('script');
			file.type = 'text/javascript';

			if(file.readyState) {// IE
				file.onreadystatechange = function() {
					if(file.readyState == 'loaded' || file.readyState == 'complete') {
						file.onreadystatechange = null;
						_call(true);
					}
				};
			} else {
				file.onload = function() { _call(true); };
			}
			file.src = url;
			document.getElementsByTagName('head')[0].appendChild(file);
		} else {
			_call(false);
		}

		return this;
	};

	// 加载外部css文件
	load.css = function( url ){
		var _call = load.callback ? load.callback : function(){};

		// 检测文件是否存在，不存在则加载，否则直接返回callback
		if(!this.isExist(url)) {
			var file = document.createElement('link');
			file.type = 'text/css';
			file.rel = 'stylesheet';

			if(file.readyState) {// IE
				file.onreadystatechange = function() {
					if(file.readyState == 'loaded' || file.readyState == 'complete') {
						file.onreadystatechange = null;
						_call(true);
					}
				};
			} else {
				file.onload = function() { _call(true); };
			}
			file.href = url;
			document.getElementsByTagName('head')[0].appendChild(file);
		} else {
			_call(false);
		}
		return this;
	};

	// 往页面里直接写入script代码
	load.script = function( code ){
		var script = document.createElement('script');
        script.type = 'text/javascript';
        try{
            script.appendChild(document.createTextNode(code));
        }catch(ex){
            script.text = code;
        }
        document.body.appendChild(script);
        return this;
	};

	// 往页面里直接写入style样式
	load.style = function( code ){
		var style = document.createElement('style');
        style.type = 'text/css';
        try{
            style.appendChild(document.createTextNode(code));
        }catch(ex){
            style.styleSheet.cssText = code;
        }
        document.getElementsByTagName('head')[0].appendChild(style);
        return this;
	};

	// 根据文件路径，判断是js还是css，返回文件类型
	load._checkType = function( url ){
		if(!url){ return; }

		var tp = url.indexOf('.js') > -1 
			   ? 'js' 
			   : url.indexOf('.css') > -1 ? 'css' : null;
		return tp;
	};

	//检查文件是否存在
	load.isExist = function( url ){
		if(!url){ return; }
		var tp = load._checkType(url);
		if(!tp){ xue.alert('文件格式不对'); return; }

		var tag = tp == 'js' ? 'script' : 'link';
		var src = tp == 'js' ? 'src' : 'href';
		var _files = document.getElementsByTagName(tag);
		for(var i = 0, len = _files.length; i < len; i++) {
			if(_files[i][src].indexOf(url) > -1) {
				return true;
			}
		}
		return false;
	};

})();

// xue.load = {
//     filesAdded : {},
//     js : function(src){
//         if(this.filesAdded[src]){
//             return this.filesAdded;
//         }
//         var script = document.createElement('script');
//         script.type = 'text/javascript';
//         script.src = src;
//         this.filesAdded[src] = true;
//         // document.body.appendChild(script);
//         document.getElementsByTagName('head')[0].appendChild(script);
//     },
//     script : function(code){
//         var script = document.createElement('script');
//         script.type = 'text/javascript';
//         try{
//             script.appendChild(document.createTextNode(code));
//         }catch(ex){
//             script.text = code;
//         }
//         document.body.appendChild(script);
//     },
//     css : function(href){
//         if(this.filesAdded[href]){
//             return 0;
//         }
//         var link = document.createElement('link');
//         link.type = 'text/css';
//         link.rel = 'stylesheet';
//         link.href = href;
//         this.filesAdded[href] = true;
//         document.getElementsByTagName('head')[0].appendChild(link);
//     },
//     style : function(code){
//         var style = document.createElement('style');
//         style.type = 'text/css';
//         try{
//             style.appendChild(document.createTextNode(code));
//         }catch(ex){
//             style.styleSheet.cssText = code;
//         }
//         document.getElementsByTagName('head')[0].appendChild(style);
//     },
//     isload : function(url, tp){

//     }
// };


/**
 * 加载script文件
 * @param {String} 		url
 * @param {sting}		place: 加载文件的位置：head or body
 * @param {Function}	callback
 */
xue.loader = xue.loader || function(url, callback, isBody) {

	// 如果没有url则返回；
	if(!url) { return; }

	var _call = callback ? callback : function(){};

	// 声明一个“检查文件是否已经存在”的函数，返回布尔值；
	var _isLoad = function() {
		var _scripts = document.getElementsByTagName('script');
		for(var i = 0, len = _scripts.length; i < len; i++) {
			if(_scripts[i].src.indexOf(url) > -1) {
				return true;
			}
		}
		return false;
	}();

	// 检测文件是否存在，不存在则加载，否则直接返回callback
	if(!_isLoad) {
		var script = document.createElement('script');
		script.type = 'text/javascript';

		if(script.readyState) {// IE
			script.onreadystatechange = function() {
				if(script.readyState == 'loaded' || script.readyState == 'complete') {
					script.onreadystatechange = null;
					_call(true);
				}
			};
		} else {
			script.onload = function() { _call(true); };
		}
		script.src = url;
		// 文件加入的位置：如果 isBody = true 则在body后面追加，否则追加到head后面
		var _place = (isBody) ? 'body' : 'head';
		document.getElementsByTagName(_place)[0].appendChild(script);
	} else {
		_call(false);
	}
	return this;
};


/**
 * 模块添加
 * @param  {string}   moduleName  模块名称
 * @param  {Function} callback    回调函数
 * @param  {Boolean}  isQueue  	  是否加入队列：在队列中的文件逐个加载（非异步）
 * @return {[type]}         	  加载完成后返回xue对象，可直接链式调用，
 *
 * @example:
 *
 * 			xue.add('pages', function(){
 * 			
				// 将分页扩展到xue对象下；
				xue.extend('pages', ui.pages);

 * 			}).use('pages', function(){
 * 				xue.pages.config({
 * 					...
 * 				});
 * 			});
 *
 * 还没想好：如何让链式调用需要放在异步加载成功之后再执行；
 */
// xue.add = xue.add || function(moduleName, callback, isQueue){};

/**
 * 模块调用方法
 *
 * 
 * @param  {string}   moduleName 模块名称
 * @param  {Function} callback   模块加载完成的回调，回调函数中会返回模块对象，方便内部调用
 * @param  {Boolean}  isQueue  	 是否加入队列：在队列中的文件逐个加载（非异步）
 * @param  {date}     timeout    延时加载的时间以毫秒为单位
 * 
 * @return {[type]}              不管模块是否加载成功，都会返回跟对象，便于链式调用 ; 
 *                               链式调用与模块的加载情况是异步的，没有依赖关系，所以在链式调用中不能确保能够调用到模块中的方法
 * @example
 
	  	window.onload = (function(){
	  			
				xue.use('pages', function(module){
					// 根据模块名称进行调用
					xue.pages.config({
						pages : 22,
						current : 1
					}).go(3);

					// 根据返回的对象进行调用
					module('page2').config({
						pages: 10,
						current: 3
					});
				}, true, 1000).test();
		});
 */
xue.use = xue.use || function(moduleName, callback, isQuequ, timeout){ 
	
	/**
	 * 声明内部变量，用于存放传入的参数
	 *
	 * n  [moduleName] : 模块名称
	 * f  [callback]   : 回调函数
	 * q  [isQueue]    : 是否加入队列
	 * t  [timeout]    : 延迟执行回调的时间
	 * tp [typeof]     : 存放参数类型
	 * 
	 * @type {[type]}
	 */
	var n = null, f = false, q = false, t = false, tp = null;

	/**
	 * 循环参数对象
	 *
	 * 根据参数的类型存入相应的变量中
	 * 如果类型不匹配则返回变量的原始值，防止变量被重复赋值
	 */
	$.each(arguments, function(k, v){
		tp = typeof v;
		n = (tp === 'string')   ? v : n;
		f = (tp === 'function') ? v : f;
		q = (tp === 'boolean')  ? v : q;
		t = (tp === 'number')   ? v : t;
	});

	// 如果没有传入模块名称，则直接返回xue对象，并提示错误；
	if(n === null || n === ''){
		alert('方法调用错误，没有模块名称');
		return xue;
	}

	/**
	 * 回调函数
	 * @return {object}   xue[n]  返回模块对象
	 */
	var callback = function(){ if(f){ return f(xue[n]); } };

	/**
	 * 模块状态判断
	 *
	 * 如果已经存在，则直接调用回调函数
	 * 如果不存在，则通过异步加载模块文件，
	 * 文件加载成功之后根据传入的timeout情况来确定是否延时触发回调函数
	 */
	if(xue[n]){
		callback();
	}else{
		// 调用异步加载方法，默认线上JS模块文件放到 sript/下面，文件名：xue.[模块名].min.js
		xue.loader('http://js04.xesimg.com/xue.' + n + '.min.js', function(){
			if(t){
				setTimeout(function(){
					callback();
				}, t);
			}else{
				callback();
			}
		});	
		
	}
	return this;
};


xue.test = function(d){
	// console.log(d);
}


/* ========================== UI 组件 =========================== */

var ui = ui || {};


ui.tabs = ui.tabs || function(id, fn){ 
	if(id === undefined){
		return ui.tabs;
	}
	
	ui.tabs.id = id || 'ui_tabs'; 
	ui.tabs.handle = $('#' + ui.tabs.id);

	if(ui.tabs.handle.length == 0){
		return ui.tabs;
	}
	ui.tabs.handle.off('click', 'li');
	ui.tabs.handle.on('click', 'li', function(){
		$(this).addClass('current').siblings('.current').removeClass('current');
		if(typeof fn === 'function'){
			return fn(this);
		}else{
			return false;
		}
	});

	return ui.tabs; 
};

xue.extend('tabs', ui.tabs);

/* ========================== module =========================== */

// var m, module = m = module || {};

// module.ajax = module.ajax || function(expr, opt, fn){
	
// 	if(expr === undefined){
// 		return module.ajax;
// 	}
	
// 	var handle = expr ? $(expr) : $(document);

// 	var opt = (typeof opt === 'object' && opt.length === undefined) ? opt : false;

// 	var defult = {
// 		dataType : 'json',
// 		timeout  : 7000,
// 		beforeSend : function(a, b, c){
// 			handle.html('<span class="ui_loading">Loading...</span>');
// 		},
// 		error      : function(a, b, c){
// 			alert(c);
// 		},
// 		complete   : function(){
// 			handle.find('.ui_loading').remove();
// 		}
// 	};
// 	var options = {};

// 	$.extend(options, defult, opt);
	
// 	$.ajax(options);

// 	if(typeof fn === 'function'){
// 		handle.ajaxSuccess(function(d){
// 			return fn(d);
// 		});
// 	}
	

// };

// (function(){
// 	var ajax = module.ajax;

// 	ajax.loading = function(expr){
// 		var handle = expr ? $(expr) : $(document);
// 		handle.html('<span class="ui_loading">Loading...</span>');
// 	};

// 	ajax.loaded = function(expr){
// 		var handle = expr ? $(expr) : $(document);
// 		handle.find('.ui_loading').remove();
// 	};

// })();

// xue.extend('ajax', module.ajax);



/**
 * 准备增加几个别名：
 *
 * x / X : 基础类
 * e / E : 事件类（event）
 * s / S : 
 * u / U : UI组件
 * r / R : 
 * m / M : 方法 / 模块
 */



/* ========== 压缩后的模块 ============= */
// 弹窗 
ui.dialog=ui.dialog||function(e){var t={};if(e&&typeof e=="object"&&e.length===undefined)return $.extend(t,ui.dialog.default,e),ui.dialog._init(t),ui.dialog;if(e&&typeof e=="string"){var n="xuebox_"+e,r=ui.dialog.queue[n];return r&&(ui.dialog.id=n,ui.dialog.box=r.DOM_BOX),ui.dialog}return $.extend(t,ui.dialog.default),ui.dialog._init(t),ui.dialog},function(){var e=ui.dialog;e.id="xuebox",e.tpl={wrap:'<div id="$id$" class="dialog">$dialog_box$ $dialog_close$ $dialog_arrow$</div>',close:'<a href="javascript:void(0);" class="dialog_close">关闭</a>',arrow:'<div class="dialog_arrow arrow_$arrow_type$"></div>',button:'<button type="button" data-type="$btn_type$" id="$id$_btn_$btn_id$" class="btn $btn_cls$ $btn_type$" href="javascript:void(0);">$btn_text$</button>',box:'<table class="dialog_box">\n	<thead><tr class="t"><td class="tl"></td><td class="tc"></td><td class="tr"></td></tr></thead>\n	<tbody class="dialog_head $is_title$">\n		<tr class="ct">\n			<td class="cl"></td>\n			<td class="dialog_handle">\n				<p class="dialog_title" id="$id$_title">$title$</p>\n			</td>\n			<td class="cr"></td>\n		</tr>\n	</tbody>\n	<tbody class="dialog_body">\n		<tr class="cc">\n			<td class="cl"></td>\n			<td id="$id$_content" class="dialog_content_wrap"><div class="dialog_content">$content$</div></td>\n			<td class="cr"></td>\n		</tr>\n	</tbody>\n	<tbody class="dialog_foot $is_buttons$">\n		<tr class="cb">\n			<td class="cl"></td>\n			<td class="dialog_buttons" id="$id$_buttons">$buttons$</td>\n			<td class="cr"></td>\n		</tr>\n	</tbody>\n	<tfoot><tr class="b"><td class="bl"></td><td class="bc"></td><td class="br"></td></tr></tfoot>\n</table>\n',mask:'<div class="dialog_mask"></div>'},e.default={content:'<div class="aui_loading"><span>loading..</span></div>',title:"消息",button:null,ok:null,no:null,submit:null,cancel:null,init:null,close:null,okVal:"确定",cancelVal:"取消",width:"auto",height:"auto",minWidth:96,minHeight:32,padding:"20px 25px",skin:"",icon:null,time:null,esc:!0,focus:!0,show:!0,follow:null,lock:!1,background:"#000",opacity:.7,duration:300,fixed:!1,left:null,top:null,zIndex:1e3,resize:!0,drag:!0,border:!0,cls:""},e.queue={},e._init=function(e){this.id=e.id?"xuebox_"+e.id:"xuebox",this.queue[this.id]=e;var t=this.tpl.wrap;t=t.replace("$id$",this.id),t=t.replace("$dialog_close$",this._getClose()),t=t.replace("$dialog_box$",this._getDOM()),t=t.replace(/\$dialog_arrow\$/,this._getArrow()),$("#xuebox_"+e.id).length>0&&$("#xuebox_"+e.id).remove(),$(t).appendTo("body"),this.box=$("#"+this.id);var t={DOM_BOX:this.box,DOM_CLOSE:this.box.find(".dialog_close"),DOM_CANCEL:this.box.find(".btn_cancel"),DOM_OK:this.box.find(".btn_ok"),DOM_BUTTONS:this.box.find(".dialog_buttons .btn"),DOM_TITLE:this.box.find(".dialog_title"),DOM_CONTENT:this.box.find(".dialog_content_wrap")};this._setOption("DOM_BOX",t.DOM_BOX),this._setOption("DOM_CLOSE",t.DOM_CLOSE),this._setOption("DOM_CANCEL",t.DOM_CANCEL),this._setOption("DOM_OK",t.DOM_OK),this._setOption("DOM_CONTENT",t.DOM_CONTENT),this._setOption("DOM_TITLE",t.DOM_TITLE),this._setOption("DOM_BUTTONS",t.DOM_BUTTONS),this._setOption(t);var n=this;this._addClick(t.DOM_CLOSE,e.close),this._addClick(t.DOM_CANCEL,e.no||e.cancel),this._addClick(t.DOM_OK,e.ok||e.submit),e.button&&e.button.length>0&&$.each(e.button,function(e,t){var r=$("#"+n.id+"_btn_"+t.id);n._addClick(r,t.fn)}),t.DOM_BOX.off("mousedown").on("mousedown",function(){n.id=$(this).attr("id"),n.box=$(this)}),this.resize();if(e.lock){var r=e.lockbg?!0:!1;this.lock(r)}e.border?t.DOM_BOX.removeClass("dialog_noborder"):t.DOM_BOX.addClass("dialog_noborder"),t.DOM_BOX.find(".dialog_head:hidden").length>0?t.DOM_CONTENT.addClass("dialog_radius_top"):t.DOM_CONTENT.removeClass("dialog_radius_top"),t.DOM_BOX.find(".dialog_foot:hidden").length>0?t.DOM_CONTENT.addClass("dialog_radius_bottom"):t.DOM_CONTENT.removeClass("dialog_radius_bottom"),e.cls&&t.DOM_BOX.addClass(e.cls),e.time&&this.timeout(e.time,t.DOM_BOX),e.follow&&this.follow(e.follow);if(!e.title){var i=t.DOM_CONTENT.find(".dialog_content"),s=i[0],o=i.height(),u=i[0].scrollHeight;(s.scrollHeight>s.clientHeight||s.offsetHeight>s.clientHeight)&&t.DOM_CLOSE.css("right",25)}},e._getClose=function(e){var t=this.queue[this.id];if(!t)return;var n=t.close?this.tpl.close:"";return n},e._getArrow=function(t){var n=this.queue[this.id];if(!n)return;var t=n.arrow;if(t){var r=e.tpl.arrow;return t=t?t===!0?"bc":t:"bc",r=r.replace("$arrow_type$",t),r}return""},e._getButton=function(){var t=this.queue[this.id];if(!t)return;var n=t.button,r=this.tpl.button,i="",s={id:/\$id\$/g,btn:/\$btn_id\$/,type:/\$btn_type\$/g,cls:/\$btn_cls\$/,text:/\$btn_text\$/};n&&typeof n=="object"&&n.length>0&&$.each(n,function(t,n){var o=r;o=o.replace(s.id,e.id),o=o.replace(s.btn,n.id),o=o.replace(s.type,"btn_"+n.tp),o=o.replace(s.cls,n.cls),o=o.replace(s.text,n.text),i+=o});var o=t.submit?t.submit:t.ok;if(t.submit||t.ok){var u=r;u=u.replace(s.type,"btn_ok"),u=u.replace(s.id,e.id),u=u.replace(s.btn,"ok"),u=u.replace(s.cls,"btn_red"),u=u.replace(s.text,t.submitVal||t.okVal),i+=u}if(t.cancel||t.no){var u=r;u=u.replace(s.type,"btn_cancel"),u=u.replace(s.id,e.id),u=u.replace(s.btn,"cancel"),u=u.replace(s.cls,"btn_gray"),u=u.replace(s.text,t.cancelVal||t.noVal),i+=u}return i},e._getDOM=function(){var e=this.queue[this.id];if(!e)return;var t=this.tpl.box,n,r,i,s,o;n=this.id||xue.getTime(),t=t.replace(/\$id\$/g,n),e.title?(t=t.replace(/\$is_title\$/,""),t=t.replace(/\$title\$/,e.title)):(t=t.replace(/\$is_title\$/,"hidden"),t=t.replace(/\$title\$/,this.default.title));var u=this._getButton(),a=u?"":"hidden";return t=t.replace("$buttons$",u),t=t.replace("$is_buttons$",a),t=t.replace("$content$",e.content),t},e._setOption=function(t,n,r){var r=r||e.id,i=e.queue[r];return i[t]=n,e.queue},e._addClick=function(t,n){var r=$(t).parents(".dialog"),i=r.length>0?r.attr("di"):this.id,s=n&&typeof n=="function"?n:function(t){e.close()},o=this;$(t).off("click").on("click",function(){o.box=$(this).parents(".dialog"),o.id=o.box.attr("id"),s(this,i)})},e._addEvent=function(e,t,n){},e.close=function(e){var t=this.queue[this.id];if(!t)return;this.box.remove(),t.lock&&this.unlock(),delete this.queue[this.id]},e.position=function(e,t,n){var r=[];if(e&&typeof e=="number"||t&&typeof t=="number"){var i=this.queue[this.id];if(!i)return;i.left=e||i.left,i.top=t||i.top,r.push(i)}else $.each(this.queue,function(){r.push(this)});return $.each(r,function(){var n=this,r=n.DOM_BOX,i={left:e||n.left||$(window).width()/2-r.width()/2,top:t||n.top||$(window).height()/2-r.height()/2};r.css({left:i.left,top:i.top})}),this},e.resize=function(e,t){var n=this.queue[this.id];if(!n)return;var r=n.DOM_BOX,i=r.find(".dialog_content");return i.css({width:e||n.width,height:t||n.height}),this.position(),this},e.zIndex=function(){},e.focus=function(){},e.getContent=function(e){var t=this.queue[this.id];if(!t)return;var n=t.DOM_CONTENT.find(".dialog_content"),r="";return e==="html"?r=n.html():e==="text"?r=n.text():r=n,r},e.lock=function(e){var t=$("body").find(".dialog_mask");t.length>0?t.show():$("body").append(this.tpl.mask);var n=$(".dialog_mask");e?n.addClass("mask_bg"):$(".dialog_mask").removeClass("mask_bg"),n.height()<$(window).height()&&n.height($(window).height())},e.unlock=function(){var e=this.queue[this.id];e.lock&&$(".dialog_mask").remove()},e.content=function(e){var t=this.queue[this.id];if(!t)return this;var n=t.DOM_BOX.find(".dialog_content");return n.html(e),this.resize(),this},e.title=function(e){var t=this.queue[this.id];if(!t)return this;var n=t.DOM_BOX.find(".dialog_title");return n.html(e),this},e.timeout=function(e,t){var n=e||2e3,r=this,i=this.queue[this.id];if(!i)return this;var t=t||i.DOM_BOX;setTimeout(function(){t.fadeOut(500),i.lock&&this.unlock(),delete r.queue[r.id]},n)},e.getSize=function(){var e=this.queue[this.id];if(!e)return this;var t=e.DOM_BOX,n=t.outerWidth(),r=t.outerHeight();return{width:n,height:r}},e._getHandleSize=function(e){var t=$(e);if(t.length===0)return!1;var n=t.offset(),r={height:t.outerHeight(!0),width:t.outerWidth(!0),left:n.left,top:n.top};return r},e.follow=function(t){var n=$(t);if(n.length===0)return this;var r=this.queue[this.id];if(!r)return this;var i=r.DOM_BOX;i.hasClass("dialog_follow")&&i.addClass("dialog_follow");var s=this._getHandleSize(n),o={width:i.outerWidth(!0),height:i.outerHeight(!0)};return e.position(s.left-o.width/2+s.width/2,s.top-o.height/2-s.height-11),this},e.arrow=function(e){}}(),function(e){}(ui.dialog),function(e){}(ui.dialog),xue.extend("dialog",ui.dialog),xue.alert=function(e,t,n){if(!e||e==="")return;var r=t||!0,i=xue.dialog;return i({id:"alert",cls:"dialog_alert",title:!1,lock:!0,close:!1,content:e,cancel:function(){typeof r=="function"&&r(),xue.dialog("alert").close()},cancelVal:"确定",submit:!1})},xue.confirm=function(e,t,n){if(!e||e==="")return;var r=t||!0,i=n||!0,s=xue.dialog;return s({id:"confirm",cls:"dialog_confirm",title:!1,lock:!0,content:e,submit:function(){typeof r=="function"&&r(),xue.dialog("confirm").close()},cancel:function(){typeof i=="function"&&i(),xue.dialog("confirm").close()}})},xue.poptips=function(e,t,n){if(!e||e==="")return;var r=n?typeof n=="number"?n:1500:null,i={id:"poptips",cls:"dialog_poptips",title:!1,submit:!1,cancel:!1,lock:!1,close:!1,follow:t||null,arrow:!0,content:'<div class="dialog_success"><em class="dialog_icon"></em>'+e+"</div>",time:r},s=xue.dialog;return s(i)},xue.win=xue.dialog,function(){var e=xue.win,t={id:"win",lock:!0,close:!0,title:"标题",content:"<div></div>",submit:!0,cancel:!0};$.each(t,function(t,n){e.default[t]=n})}();

// 分页
// ui.pages=ui.pages||function(e){return ui.pages.id=e||"ui_pages",ui.pages},function(){var e=ui.pages;e.queue={};var t={id:"ui_pages",handle:"#ui_pages",size:5,bitwise:2,current:1,pages:20,pageCount:20,pageNum:20,prevText:"上一页",nextText:"下一页",prev:".pages_prev",next:".pages_next",item:".pages_item",html:"",fn:{},firstText:null,lastText:null,isMore:!0,callback:!1},n={wrap:'<ol class="ui_pages"></ol>',page:'<li class="pages_item" data-page="$pageData$"><a href="javascript:void(0);">$pageText$</a></li>',more:'<li class="pages_more"><span>...</span></li>',current:'<li class="pages_current"><span>$pageText$</span></li>',prev:'<li class="pages_prev"><a href="javascript:void(0);" class="btn btn_gray $disable$">'+t.prevText+"</a></li>",next:'<li class="pages_next"><a href="javascript:void(0);" class="btn btn_gray $disable$">'+t.nextText+"</a></li>"};e.config=function(n){this.id=this.id===undefined?t.id:this.id,n.id=n.id||this.id,n.handle=n.handle||$("#"+n.id);var r={opt:{}};typeof n=="object"&&n.length===undefined?$.extend(r,t,n):$.extend(r,t),r.bitwise=r.size>>1,r.pageCount=Math.ceil(Number(r.pages)/Number(r.pageNum)),this.queue[this.id]=r;var i=undefined;if(r.pageClick||r.prevClick||r.nextClick)i={};return typeof r.pageClick=="function"&&(r.fn.pageClick=r.pageClick),typeof r.prevClick=="function"&&(r.fn.prevClick=r.prevClick),typeof r.nextClick=="function"&&(r.fn.nextClick=r.nextClick),this.fn(this.id,r.fn),r.current>0&&r.pageCount>0&&e(this.id).go(r.current),n=r=i=this.id=undefined,this},e.createItem=function(e,t,r){var r=r==="current"?"current":"page",t=t||e,i=n[r].replace("$pageText$",t);return i=i.replace("$pageData$",e),i},e.createBtn=function(e,t){var r=e==="prev"?"prev":"next",i=t?"btn_disable":"",s=n[r].replace("$disable$",i);return s},e.createMore=function(){var e=this.queue[this.id],t=e.isMore?n.more:"";return t},e.createPages=function(e,t){var n=this.queue[this.id],t=t||n.pageCount;n.pageCount=t>0?t:1;var e=e||n.current;n.current=e>0?e>t?t:e:1;if(t===1)return this.createItem(1,1,"current");var r,i,s,o,u,a,f,l,c,h;u=this.createBtn("prev",e===1?!0:!1),a=this.createBtn("next",e===t?!0:!1),r=Number(e-n.bitwise),r=r<1?1:r,o=Number(e+n.bitwise),o=o>t?t:o,i=this.createMore(),l=o<=n.size?"":this.createItem(1,n.firstText),c=r>t-n.size?"":this.createItem(t,n.lastText);if(t<=10){h=u;for(var p=1;p<=t;p++){var d=p===e?"current":!1;h+=this.createItem(p,p,d)}return h+=a,h}o<=n.size&&(r=1,o=n.size),r>t-n.size&&(r=t-n.size+1,o=t),s="";for(var p=r;p<=o;p++){var d=p===e?"current":!1;s+=this.createItem(p,p,d)}return h=u+l,h+=o<=n.size+1?"":i,h+=s,h+=r>=t-n.size?"":i,h+=c+a,h},e.append=function(e){var t=this.queue[this.id],e=e||t.html;$(t.handle).html(e)},e.getPagesHTML=function(){var e=this.queue[this.id],t=this.createPages(e.current,e.pageCount),r=$(n.wrap),i=r.html(t);return e.html=i,i},e.go=function(e,n){this.id=this.id||t.id;var r=this.queue[this.id];r.current=e>0?e:r.current,r.pageCount=n||r.pageCount;var i=this.getPagesHTML();return this.append(i),this},e.fn=function(t,n){var r=this.queue[t],i=function(n,i){e(t).go(n,r.pageCount)},s=function(e,t){var t=t||"page";return r.callback?r.callback(e,r.pageCount):r.fn[t+"Click"]?r.fn[t+"Click"](e,r.pageCount):"default"},o=1,u=!1,a=1;r.handle.off("click",r.item),r.handle.on("click",r.item,function(){o=$(this).data("page"),u=s(o,"page");if(u!==undefined)return i(o)}),r.handle.off("click",r.prev),r.handle.on("click",r.prev,function(){a=r.current,a--,o=a>0?a:0,u=s(o,"prev");if(u!==undefined)return i(o)}),r.handle.off("click",r.next),r.handle.on("click",r.next,function(){a=r.current,a++,o=a>r.pageCount?r.pageCount:a,u=s(o,"next");if(u!==undefined)return i(o)})},e.click=function(t){var n=this.queue[this.id];if(typeof t=="function"){var r=e(this.id).getPagesHTML();return t(n.current,r)}}}(),xue.pages=ui.pages;
ui.pages=ui.pages||function(e){return ui.pages.id=e||"ui_pages",ui.pages},function(){var e=ui.pages;e.queue={};var t={id:"ui_pages",handle:"#ui_pages",size:5,bitwise:2,current:1,pages:20,pageCount:20,pageNum:20,prevText:"上一页",nextText:"下一页",prev:".pages_prev",next:".pages_next",item:".pages_item",html:"",fn:{},firstText:null,lastText:null,isMore:!0,callback:!1},n={wrap:'<ol class="ui_pages"></ol>',page:'<li class="pages_item" data-page="$pageData$"><a href="javascript:void(0);">$pageText$</a></li>',more:'<li class="pages_more"><span>...</span></li>',current:'<li class="pages_current"><span>$pageText$</span></li>',prev:'<li class="pages_prev"><a href="javascript:void(0);" class="btn btn_gray $disable$">'+t.prevText+"</a></li>",next:'<li class="pages_next"><a href="javascript:void(0);" class="btn btn_gray $disable$">'+t.nextText+"</a></li>"};e.config=function(n){this.id=this.id===undefined?t.id:this.id,n.id=n.id||this.id,n.handle=n.handle||$("#"+n.id);var r={opt:{}};typeof n=="object"&&n.length===undefined?$.extend(r,t,n):$.extend(r,t),r.bitwise=r.size>>1,r.pageCount=Math.ceil(Number(r.pages)/Number(r.pageNum)),this.queue[this.id]=r;var i=undefined;if(r.pageClick||r.prevClick||r.nextClick)i={};return typeof r.pageClick=="function"&&(r.fn.pageClick=r.pageClick),typeof r.prevClick=="function"&&(r.fn.prevClick=r.prevClick),typeof r.nextClick=="function"&&(r.fn.nextClick=r.nextClick),this.fn(this.id,r.fn),r.current>0&&r.pageCount>0&&e(this.id).go(r.current),n=r=i=this.id=undefined,this},e.createItem=function(e,t,r){var r=r==="current"?"current":"page",t=t||e,i=n[r].replace("$pageText$",t);return i=i.replace("$pageData$",e),i},e.createBtn=function(e,t){var r=e==="prev"?"prev":"next",i=t?"btn_disable":"",s=n[r].replace("$disable$",i);return s},e.createMore=function(){var e=this.queue[this.id],t=e.isMore?n.more:"";return t},e.createPages=function(e,t){var n=this.queue[this.id],t=t||n.pageCount;n.pageCount=t>0?t:1;var e=e||n.current;n.current=e>0?e>t?t:e:1;if(t===1)return" ";var r,i,s,o,u,a,f,l,c,h;u=this.createBtn("prev",e===1?!0:!1),a=this.createBtn("next",e===t?!0:!1),r=Number(e-n.bitwise),r=r<1?1:r,o=Number(e+n.bitwise),o=o>t?t:o,i=this.createMore(),l=o<=n.size?"":this.createItem(1,n.firstText),c=r>t-n.size?"":this.createItem(t,n.lastText);if(t<=10){h=u;for(var p=1;p<=t;p++){var d=p===e?"current":!1;h+=this.createItem(p,p,d)}return h+=a,h}o<=n.size&&(r=1,o=n.size),r>t-n.size&&(r=t-n.size+1,o=t),s="";for(var p=r;p<=o;p++){var d=p===e?"current":!1;s+=this.createItem(p,p,d)}return h=u+l,h+=o<=n.size+1?"":i,h+=s,h+=r>=t-n.size?"":i,h+=c+a,h},e.append=function(e){var t=this.queue[this.id],e=e||t.html;$(t.handle).html(e)},e.getPagesHTML=function(){var e=this.queue[this.id],t=this.createPages(e.current,e.pageCount),r=$(n.wrap),i=r.html(t);return e.html=i,i},e.go=function(e,n){this.id=this.id||t.id;var r=this.queue[this.id];r.current=e>0?e:r.current,r.pageCount=n||r.pageCount;var i=this.getPagesHTML();return this.append(i),this},e.fn=function(t,n){var r=this.queue[t],i=function(n,i){e(t).go(n,r.pageCount)},s=function(e,t){var t=t||"page";return r.callback?r.callback(e,r.pageCount):r.fn[t+"Click"]?r.fn[t+"Click"](e,r.pageCount):"default"},o=1,u=!1,a=1;r.handle.off("click",r.item),r.handle.on("click",r.item,function(){o=$(this).data("page"),u=s(o,"page");if(u!==undefined)return i(o)}),r.handle.off("click",r.prev),r.handle.on("click",r.prev,function(){a=r.current,a--,o=a>0?a:0,u=s(o,"prev");if(u!==undefined)return i(o)}),r.handle.off("click",r.next),r.handle.on("click",r.next,function(){a=r.current,a++,o=a>r.pageCount?r.pageCount:a,u=s(o,"next");if(u!==undefined)return i(o)})},e.click=function(t){var n=this.queue[this.id];if(typeof t=="function"){var r=e(this.id).getPagesHTML();return t(n.current,r)}}}(),xue.pages=ui.pages;


/* ========== 全局事件 ============= */
// window尺寸发生变化时
$(window).resize(function(){
	if($('.dialog').length > 0){
		xue.win.position();
	}
});
// 页面滚动时
$(window).scroll(function(){

});

$(function(){
	//头部选课程
    $('#header').off('click', '.header_box .navs li.course').on('click', '.header_box .navs li.course', function(a){
        var that = $(this);
        // var 
        // var re = a.relatedTarget;
        // var c = that.find(re);

        // setTimeout(function(){
	        // if(c.length > 0){
		        // that.addClass('course_select');
	        // }
        // }, 500);

   //      setTimeout(function(){
			if(that.hasClass('course_select')){
	            that.removeClass('course_select');
	        }else{
	            that.addClass('course_select');
	        }
   //      }, 500);
        


        $('#header').off('mouseout', '.navs li.course').on('mouseout', '.navs li.course', function(event){
        	var _re = event.relatedTarget;
	        var _c = $(this).find(_re);
	        if(_c.length == 0){
	            setTimeout(function(){
            		that.removeClass('course_select');
	            }, 500);
	        }
        });
    });
    // 头部右侧点击下拉
    $('#header ').off('click', '.loginbar li:not(.lines)').on('click', '.loginbar li:not(.lines)', function(){
        var that = $(this), box = that.find('.layer_head');
        var newMessage = $('.layer_news_tips');
        if(box.length > 0){
            if(that.hasClass('current')){
                that.removeClass('current');
                newMessage.show();
            }else{
                that.addClass('current');
                that.siblings('li').removeClass('current');
                newMessage.hide();
            }
            
        }
    });

    // 头部新消息浮层的关闭事件
    $('#header').off('click', '.layer_news_tips .close').on('click', '.layer_news_tips .close', function(){
        var box = $(this).parents('.layer_news_tips');
        box.remove();
    });

    // 头部信息点击事件
    $('#header').off('click', '.msg_tips a').on('click', '.msg_tips a', function(){
        var that = this, a = $(this).attr('href').split('#_'), loc = window.location;
        var link = { url : a[0], tp  : a[1] };
        var href = { url : loc.pathname, tp  : loc.href.split('#_')[1] };
        // 如果不是消息页面，直接跳转
        if(link.url !== href.url){ return true; }

        // 如果时信息页面则执行
        xue.use('message', function(){
            xue.message.setCurrent(link.tp);
        });
    });
	// 绑定老师头像切换事件
    $('.layout').off('click', '.avatar_roll a').on('click', '.avatar_roll a', function(){
        var that = $(this);
        if(that.hasClass('none')){
            return false;
        }else{
            xue.use('avatar', function(){
                xue.avatar.toggle(that);
            });            
        }
    });
    
    var userinfo_temp = false;
    // 绑定所有V用户的鼠标滑过事件：弹出用户信息
    $('body').off('mouseover', '.ui_userinfo').on('mouseover', '.ui_userinfo', function(){
        var d = $(this).data();
        var that = $(this);
        if(!d.params){ return; }

        var temp = that.find('.pop_userinfo_temp');
        if(temp.length > 0){
            var msg = temp.html();
            xue.use('userinfo', function(){
                xue.userinfo.show(that, msg);
            });
        }else{
            var url = window.location.hostname == 'v04.xesui.com' ? '../json/pop_userinfo.php' : '/Dynamics/ajaxTeacherInfo';
            $.ajax(url, {
                type     : 'POST',
                dataType : 'html',
                data     : d.params,
                success  : function( result ){
                    var msg = xue.ajaxCheck.HTML(result);
                    if(msg){
                        xue.use('userinfo', function(){
                            if(xue.userinfo){
                                xue.userinfo.show(that, msg);
                            }
                        });
                    }
                }
            });
        }

        userinfo_temp = true;

        that.off('mouseout').on('mouseout', function(a, b, c, d){
            userinfo_temp = false;
            var re = $(a.relatedTarget);
            var c = $('.dialog_userinfo').find(re);

            if(c.length > 0){
                userinfo_temp = true;
            }
            setTimeout(function(){
                if(!userinfo_temp){
                    xue.win('userinfo').close();
                }
            }, 500);
        });

    });

    $('body').off('mouseover', '.dialog_userinfo').on('mouseover', '.dialog_userinfo', function(a){
        userinfo_temp = true;
    });

    $('body').off('mouseout', '.dialog_userinfo').on('mouseout', '.dialog_userinfo', function(a){
        var re = a.relatedTarget;
        var c = $(this).find(re);
        if(c.length == 0){
            userinfo_temp = false;
            setTimeout(function(){
                if(!userinfo_temp){
                    xue.win('userinfo').close();
                }
            }, 500);
        }
    });

    xue.use('feedback');
  
});


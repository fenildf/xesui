/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-14 10:27:32
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xue.page.home.js
 * @description 学习中心全局交互
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

$(function(){
   

    // 绑定收藏事件
    $('.layout_body').off('click', '.feed_btn_fav.fav_add').on('click', '.feed_btn_fav.fav_add', function(){
        var d = $(this).data();
        var that = $(this);
        var url = window.location.hostname == 'v04.xesui.com' ? '../json/fav.json' : '/Homes/ajaxAddCollect';

        $.ajax({
            url: url,
            data:d.params,
            type : 'POST',
            dataType:'json',
            success:function(result){
                var msg = xue.ajaxCheck.JSON(result);
                if(msg){
                    xue.poptips('收藏成功', that, true);

                    var re = /\(([^\(]*)\)/;

                    //获取原来的内容
                    var oldtext = that.html();

                    // 获取括号内的数字，进行累加
                    var text = oldtext.match(re);
                    var num = Number(text[1]);
                    num++;

                    // 替换原来括号中的数字为累加后的数字
                    var newtext = '取消收藏 <strong>(' + num + ')</strong>';

                    that.html(newtext);

                    that.removeClass('fav_add');
                    that.addClass('fav_end');
                }else{
                    return ;
                }
            }
        });
    });

    // 绑定取消收藏事件
    $('.layout_body').off('click', '.feed_btn_fav.fav_end').on('click', '.feed_btn_fav.fav_end', function(){
        var d = $(this).data();
        var that = $(this);
        var url = window.location.hostname == 'v04.xesui.com' ? '../json/fav.json' : '/Homes/ajaxCancelCollect';

        $.ajax({
            url: url,
            data:d.params,
            type : 'POST',
            dataType:'json',
            success:function(result){
                var msg = xue.ajaxCheck.JSON(result);
                if(msg){
                    xue.poptips('已取消', that, true);

                    var re = /\(([^\(]*)\)/;

                    //获取原来的内容
                    var oldtext = that.html();

                    // 获取括号内的数字，进行累加
                    var text = oldtext.match(re);
                    var num = Number(text[1]);
                    num--;

                    // 替换原来括号中的数字为累加后的数字
                    // var newtext = oldtext.replace(re,'(' + num + ')');
                    var newtext = '收藏 <strong>(' + num + ')</strong>';

                    that.html(newtext);

                    that.removeClass('fav_add');
                    that.addClass('fav_end');
                }else{
                    return ;
                }
            }
        });
    });

    /**
     * 评论相关
     */
    // 切换评论区域
    $('.layout_body').off('click', '.feed_btn_comment').on('click', '.feed_btn_comment', function(){
        var that = $(this);
        if(that.data('type') != 2){
            xue.use('comment', function(){
                xue.comment.toggle(that);
            });         
        }
    });
    // 提交评论
    $('.layout_body')
    .off('click', '.feed_comment:visible .comment_button .btn_submit')
    .on('click', '.feed_comment:visible .comment_button .btn_submit', function(){
        var that = $(this);
        xue.use('comment', function(){
            xue.comment.post(that);
        });
    });
    // 计算评论字数
    $('.layout_body').off('keydown', '.comment_textarea textarea').on('keydown', '.comment_textarea textarea', function(){
        var that = $(this);
        xue.use('comment', function(){
            xue.comment.countsize(that);
        });
    });



    // 动态大小图切换
    $('.layout').off('click', '.feed_media .media_item').on('click', '.feed_media .media_item', function(){
        var that = this;
        xue.use('feed', function(){
            xue.feed.img.toggle( that );
        });
    });


    // 发布活动/动态里面的选择上传图片
    $('.layout').off('change', '.ui_comment_event .comment_files').on('change', '.ui_comment_event .comment_files', function(){
        var that = this;
        xue.use('feed', function(){
            xue.feed.upload.chooseFile( that );
        });
    });


    // 发布动态
    // $('.layout').off('click', '.ui_comment_event .btn_submit').on('click', '.ui_comment_event .btn_submit', function(){
    //     var that = this;
    //     var feed_form = $(that).parents('form.comment_form');
    //     // xue.use('feed', function(){
    //         // xue.feed.post.submit(feed_form);
    //     // });
    // });
    

    // 绑定系统通知关闭事件
    $('.layout').off('click', '.ui_tips .close').on('click', '.ui_tips .close', function(){
        var that = $(this);
        var item = that.parents('.tips');
        var next = item.next();
        
        item.fadeOut(function(){
            if(next.length == 0){ return false; }
            next.show();
        });

    });


});

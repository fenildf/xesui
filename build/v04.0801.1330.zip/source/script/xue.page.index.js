/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-12 16:52:31
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xue.page.index.js
 * @description 首页文件
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

// var dyn_btn = $('#index_dyn_tab'),
//     dyn_box = $('#index_dyn');

// if(dyn_btn.length > 0){
//     xue.tabs('index_dyn_tab', function(d){
//         var d = $(d).data();
//         $.ajax({
//             url : d.url,
//             type:'GET',
//             data : d.params,
//             dataType:'html',
//             success: function(d){
//                 dyn_box.html(d);
//             }
//         });
//     });

//     var _indexTabCurrent = dyn_btn.find('li[data-default="1"]');
//     if(_indexTabCurrent.length > 0){
//         _indexTabCurrent.click();
//     }else{
//         dyn_btn.find('li:first').click();
//     }    
// }



// 课程详情页
function courseInfo(id){
    var _box = $(id),
        _top = (id == '#course_content') ? 39 : 39,
        _top = _box.offset().top - _top;
    $(window).scrollTop(_top);
  }

function setCourseHandleCurrent(d){
    d.addClass('current').siblings().removeClass('current');
}
// 课程列表
function filterDown(aaa) {
    var con = $(aaa).next();
    if(con.is(':visible')) {
        con.hide();
    } else {
        con.show();
    }

}
function headSelectCourse(d){}
//更多条件
function filterTextMore(d) {
    var con = $(d).parent().prevAll(".filter_other");
    var bord = $(d).parent().prevAll(".filter_item").eq(3);
    var icon = $(d);
    if(icon.hasClass('up')){
        con.hide();
        icon.removeClass("up");
        bord.addClass("border_none");
    }else{
        con.show();
        icon.addClass("up");
        bord.removeClass("border_none");
    }   
}
$(function(){
    

    //课程详情页
    $('.tabs_title_item li').click(function(){
        var _id = $(this).attr('con');
        if(_id){
            setCourseHandleCurrent($(this));
            courseInfo('#' + _id);
        }
    });

    //课程列表
    $('.filter_down').click(function(){
        filterDown(this);
    });
    //更多条件
    $('.filter_more p').click(function(){
        filterTextMore(this);    

     });

  

});
/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-25 10:54:18
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name 
 * @description 
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */


// $(function(){
//     $('#username, #password, #repassword, #phone, #phonecode, #grade').off('blur').on('blur', function(){
//         var that = $(this), id = this.id;
//         xue.formCheck.box[id] = that;
//         xue.formCheck[id]();
//         var error = xue.formCheck.isError();
//     });

//     $('.get_phonecode').off('click', '.vcode').on('click', '.vcode', function(){
//         var check = xue.formCheck;
//         var vcode = xue.formCheck.vcode;

//         check.box.phone = $('#phone');
//         if(check.phone()){
//             var url = '/user/getPassCode';
//             $.ajax(url, {
//                 type : 'POST',
//                 dataType : 'json',
//                 data : {phone: $('#phone').val()},
//                 error : function( result ){
//                     console.log(result);
//                 },
//                 success : function( result ){
//                     console.log(result);
//                 }
//             });
//             vcode.box = $(this);
//             vcode.count();
//         }
//     });

//     $('#form_register').off('click', '.btn_submit:not(.btn_disable)').on('click', '.btn_submit:not(.btn_disable)', function(){
//         var that = $(this);
        
//         var check = xue.formCheck;

//         var list = $('#username, #password, #repassword, #phone, #phonecode, #grade');
//         list.each(function(){
//             var that = $(this), id = this.id;
//             if(that.length > 0){
//                 check.box[id] = that;
//                 check[id]();                
//             }
//         });

//         if(check.isError()){
//             return false;
//         }else{
//             return true;
//         }
  
//     });

// });


xue.formCheck = xue.formCheck || {};

(function(){
    var f = xue.formCheck;

    f.box = {
        form       : '#form_register',
        username   : '#username',
        password   : '#password',
        repassword : '#repassword',
        phone      : '#phone',
        phonecode  : '#phonecode',
        grade      : '#grade',
        username   : '#username'
    };

    f.disable = function( expr ){
        var btn = expr ? $(expr) : $('#form_submit');

        var mask = $('<div class="form_submiting"></div>');
        mask.css({
            width : btn.width(),
            height: btn.height(),
            left  : btn.offset().left,
            top  : btn.offset().top
        });

        if($('.form_submiting').length == 0){
            mask.appendTo('body');
        }

        $('#form_submit').addClass('btn_disable');
    };

    f.enable = function(){
        $('#form_submit').removeClass('btn_disable');
        $('.form_submiting').remove();
    };

    f.isError = function(){
        var form = $(f.box.form),
            error = form.find('.error');
        if(error.length == 0){
            f.enable();
            return false;
        }else{
            f.disable();
            return true;
        }
    };
    f.username = function( val, fn ){
        var box = $(f.box.username),
            val = box.val();
        if(val == ''){
            f.setTips('username', '用户名不能为空');
        }else{
            var isEmail = f.email();
            if(isEmail){
                // 这里进行ajax验证用户名是否已被注册
                if(fn && typeof fn == 'function'){
                    fn();
                }
            }
        }
        return this;
    };

    f.email = function(){
        var reg = /^\w+([\.\-]\w+)*\@\w+([\.\-]\w+)*\.\w+$/;
        var box = $(f.box.username),
            val = box.val();
        if(reg.test(val)){
            f.clearTips('username');
            return true;
        }else{
            f.setTips('username', '请输入正确的邮箱地址');
            return false;
        }
    };

    f.password = function(){
        var box = $(f.box.password);
        if(box.val() == ''){
            f.setTips('password', '密码不能为空');
        }else{
            xue.formCheck.checkStrength();
        }
        return this;
    };

    f.repassword = function(){
        var box = $(f.box.repassword), val = box.val();
        if(val == ''){
            f.setTips('repassword', '确认密码不能为空');
        }else if(val != $(f.box.password).val()){
            f.setTips('repassword', '两次输入的密码不相同');
        }else{
            f.clearTips('repassword');
        }
        return this;
    };

    f.phone = function(){
        var box = $(f.box.phone),
            tips = $('#tips_phone');
        if(box.val() == ''){
            f.setTips('phone', '手机号不能为空');
            f.vcode.clear();
            return false;
        }else{
            var isPhone = (/^(13|15|18)[0-9]{9}$/.test(box.val()) ? true : false);
            if(isPhone){
                f.clearTips('phone');
                return true;
            }else{
                f.setTips('phone', f.tips.phone);
                f.vcode.clear();
                return false;
            }
        }
        // return this;
    };

    f.phonecode = function(){
        var box = $(f.box.phonecode),
            tips = $('#tips_phonecode');
        if(box.length == 0){ return; }
        var val = box.val();
        if(val == ''){
            f.setTips('phonecode', '手机验证码不能为空');
        }else{
            if(val.length == 4 && /^[1-9]\d*|0$/.test(val)){
                f.clearTips('phonecode');
            }else{
                f.setTips('phonecode', f.tips.phoneCode);
            }
        }
        return this;
    };

    f.getPhoneCode = function(){

    };

    /* 获取验证码部分 */

    f.vcode = f.vcode || {};

    f.vcode.time = 60;

    f.vcode.interval = null;

    f.vcode.box = '#vcode';

    f.vcode.cls = { btn : 'vcode', count : 'vcode_countdown' };

    f.vcode.count = function(){
        var that = this,
            box = $(that.box);
        if(box.length == 0){ return; }

        that.clear();

        box.removeClass().addClass(that.cls.count).text('60秒后，可重新获取');
        $(f.box.phone).prop('readonly', true);

        $('#phonecode').focus();

        that.interval = setInterval(function(){
            if(that.time > 0){
                that.time--;
                box.text(that.time + '秒后，可重新获取');
            }else{
                that.clear();
                box.removeClass().addClass(that.cls.btn);
            }
        }, 1000);
    };

    f.vcode.clear = function(){
        var that = this,
            box = $(that.box);
        if(box.length == 0){ return; }

        that.time = 60;
        clearInterval(that.interval);
        $(f.box.phone).prop('readonly', false);
        box.removeClass().addClass(that.cls.btn).text('获取短信验证码');
    };

    f.vcode.ajax = function(){};

    f.grade = function(){
        var box = $(f.box.grade),
            val = box.val();
        if(val == ''){
            f.setTips('grade', '请选择年级');
        }else{
            f.clearTips('grade');
        }
        return this;
    };


    f.tips = {
        empty : '$val$不能为空',
        email : 'Email格式不正确',
        username : '请输入正确的用户名',
        password : '不能与用户名相同',
        repassword : '两次输入的密码不相同',
        phone : '请输入正确的手机号',
        phoneCode : '手机验证码不正确',
        grade : '请选择正确的年级',
        strength : {
            0 : '太短',
            1 : '弱',
            2 : '一般',
            3 : '很好'
        }
    }

    f.clearTips = function( id ){
        var box = $('#tips_' + id);
        if(box.length == 0){ return; }
        box.removeClass().addClass('tips').empty();
        return this;
    };

    f.setTips = function( id, tips, tp ){
        var box = $('#tips_'+id), cls = tp || 'error';
        if(box.length == 0){ return; }
        // console.log(cls);
        box.removeClass().addClass('tips ' + cls);
        box.html(tips || f.tips[id]);
        return this;
    };

    f.checkStrength = function(){
        var username = $(f.box.username),
            password = $(f.box.password);

        var score = f.strength(password.val(),username.val());

        var box = $('#tips_password');
        var tips = '';
        if(score == -4)    {
            // box.html(f.tips.strength[0]);
            tips = f.tips.strength[0];
        }else if(score == -2){
            // box.html('与用户名相同');
            tips = f.tips.password;
        }else{
            var color = score < 34 ? '#edabab' : (score < 68 ? '#ede3ab' : '#d3edab');
            var text = score < 34 ? f.tips.strength[1] : (score < 68 ? f.tips.strength[2] : f.tips.strength[3]);
            var width = score + '%';
            tips = '<span style="width:' + width + ';display:block;overflow:hidden;height:5px;line-height:5px;background:'+color+';"></span>'+text;
        }
        f.setTips('password', tips, 'success');
    };

    f.strength = function(password, username){
        var score = 0;
        if (password.length < 4) { return -4; }
        if (typeof(username) != 'undefined' && password.toLowerCase() == username.toLowerCase()) { return -2 }
        score += password.length * 4;
        score += (repeat(1, password).length - password.length) * 1;
        score += (repeat(2, password).length - password.length) * 1;
        score += (repeat(3, password).length - password.length) * 1;
        score += (repeat(4, password).length - password.length) * 1;
        if (password.match(/(.*[0-9].*[0-9].*[0-9])/)) { score += 5; }
        if (password.match(/(.*[!,@,#,$,%,^,&,*,?,_,~].*[!,@,#,$,%,^,&,*,?,_,~])/)) { score += 5; }
        if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) { score += 10; }
        if (password.match(/([a-zA-Z])/) && password.match(/([0-9])/)) { score += 15; }
        if (password.match(/([!,@,#,$,%,^,&,*,?,_,~])/) && password.match(/([0-9])/)) { score += 15; }
        if (password.match(/([!,@,#,$,%,^,&,*,?,_,~])/) && password.match(/([a-zA-Z])/)) { score += 15; }
        if (password.match(/^\w+$/) || password.match(/^\d+$/)) { score -= 10; }
        if (score < 0) { score = 0; }
        if (score > 100) { score = 100; }
        return score;

        function repeat(len, str) {
            var res = "";
            for (var i = 0; i < str.length; i++) {
                var repeated = true;
                for (var j = 0, max = str.length - i - len; j < len && j < max; j++) { repeated = repeated && (str.charAt(j + i) == str.charAt(j + i + len)); }
                if (j < len) { repeated = false; };
                if (repeated) { i += len - 1; repeated = false; } else { res += str.charAt(i); }
            }
            return res;
        }
    };

})();
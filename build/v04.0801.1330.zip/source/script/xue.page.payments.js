/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-14 12:45:29
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name xue.page.payments.js
 * @description 支付页面交互
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

$(function(){
    // 绑定老师头像切换事件
    $('.layout').off('click', '.avatar_roll a').on('click', '.avatar_roll a', function(){
        var that = $(this);
        if(that.hasClass('none')){
            return false;
        }else{
            xue.use('avatar', function(){
                xue.avatar.toggle(that);
            });            
        }
    });
});

var addressInput = '#realname, #add_province, #add_city, #add_country, #address, #zipcode, #phone';
var paytpl = '课程总金额：￥$course$.00 + 快递费：￥$express$.00 - 帐户余额：￥$balance$.00 = 您需支付：<strong>￥$pay$.00</strong><input value="20" id="carriage_hidden" type="hidden">'

// 显示状态
var state = {
    address : false
};

var price = {
    course  : 0,    // 课程总金额（不含代金卡）
    order   : 0,    // 订单金额
    express : 0,    // 快递费
    card    : 0,    // 代金卡
    balance : 0,    // 余额
    pay     : 0     // 最后支付金额
};

var box = {
    order   : '.p_order'
    course  : '#t_course',      // 课程金额
    card    : '#p_card',        // 代金卡
    express : '#p_express',     // 快递费
    balance : '#p_balance',     // 余额
    pay     : '#p_pay'          // 支付总额
};

// 初始化价格
function initPrice(){
    price.course = Number($(box.course).text());
    price.balance = Number($('#balance').text());
}
// 设置订单金额（顶部的）
function setOrderPrice(){
    price.order = price.course - price.card;
    $(box.card).text(price.card);
    $(box.order).text(price.order);
}
// 设置支付金额（底部的）
function setPayPrice(){
    price.pay = price.order + price.express - price.balance;
    $(box.order).text(price.order);
    $(box.express).text(price.express);
    $(box.balance).text(price.balance);
    $(box.pay).text(price.pay);
}










































;(function(){
    









    // 支付方式切换效果
    var paytab = $('.payment_tabs'),
        paybox = $('.payment_content .payment_bank');

    paytab.off('click', 'li').on('click', 'li', function(){
        var index = paytab.find('li').index(this);
        
        // 设置支付类型
        
        // 货到付款
        if(index === 0){
            $('#pay_type').val(200000);
            $('.express_title, .order_address').show();

            var _money = $('.all_money'),
                _carriage = $('#carriage_hidden');
            if(price.course <= 50){
                price.express = Number($('#carriage_hidden').val());
            }
        // 在线支付
        }else{
            $('#pay_type').val(10001);
            if($('.bill_checked').prop('checked')){
                $('.express_title, .order_address').show();
            }else{
                $('.express_title, .order_address').hide();
            }
            price.express = 0
        }
        $(this).addClass('current').siblings('li').removeClass('current');
        paybox.eq(index).removeClass('hidden').siblings('.payment_bank').addClass('hidden');
        setAllPrice();
    });

    // 展开/收起效果
    var foldtab = $('.ui_folds');
    foldtab.off('click', '.folds_title').on('click', '.folds_title', function(){
        var _fold = $(this).parent('.ui_folds');
        var cls = 'folds_open';
        if(_fold.hasClass('folds_open')){
            _fold.removeClass(cls);
        }else{
            _fold.addClass(cls);
        }
    });

    //课程总价格
    price.course = getCoursePrice();

    //账户余额
    price.balance = Number($('#balance').text());

    //在线支付方式
    $('input[name="bank_id"]').click(function(){
        var that = $(this);
        var payid = that.attr('payid'),
            paytp = that.attr('paytype');
        $('#paytype_id').val(payid);
        $('#onlinePayType').val(paytp);
    });

    // 0元课程
    if(price.course === 0){
        $('.paytype_title, .ui_payment, .ui_folds, .express_title, .order_address').hide();
        var _html = paytpl.replace('$course$', 0);
        _html = _html.replace('$express$', 0);
        _html = _html.replace('$balance$', 0);
        _html = _html.replace('$pay$', 0);
        $('.all_money').html(_html);
    }

    // 余额支付
    if(price.balance >= price.course){
        $('.paytype_title, .ui_payment, .express_title, .order_address').hide();
        var _html = paytpl.replace('$course$', price.course);
        _html = _html.replace('$express$', 0);
        _html = _html.replace('$balance$', price.course);
        _html = _html.replace('$pay$', 0);
        $('.all_money').html(_html);
    }

    // 如果切换到在线支付，则隐藏收货地址
    // var paytype = $('.payment_tabs li.current');
    if($('.payment_tabs li.current').index() === 1){
        $('.express_title, .order_address').hide();
    }

    // 收货地址点击切换
    $('.address_list input:radio').on('click', function(){
        var newAddress = $('#details-form');
        if(this.id === 'addid_0'){
            newAddress.show();
            $(addressInput).val('');
            $('#add_id').val(0);
            renderAreaSelect();
        }else{
            newAddress.hide();
        }
    });

    // 保存收货地址
    $('#address_submit_btn').on('click', function(){
        var inputs = $(addressInput),
            errorbox  = $('.error_tips_address');

        var ids = {
            realname     : '收货人姓名',
            province : '省份',
            city     : '城市',
            country  : '地区',
            address      : '详细地址',
            zipcode      : '邮政编码',
            phone        : '手机',
            add_province : '省份',
            add_city     : '城市',
            add_country  : '地区'
            
        };
        var id, error = [], error_text = '', tpl = '$input$ 不能为空';
        inputs.each(function(){
            id = this.id;
            if($(this).val() === ''){
                error.push(ids[id]);
                $(this).addClass('error');
            }else{
                $(this).removeClass('error');
            }
        });
        if(error.length > 0){
            error_text = error.toString();
            errorbox.text(tpl.replace('$input$', error_text));        
        }else{
            errorbox.empty();
            saveNewAddress(inputs);
        }

    });

    // 如果发票有值则显示第二个div
    var invoice = $('#invoice_head'),
        invoice_box = $('.invoice_info');
    if(invoice.val()){
        invoice_box.eq(0).addClass('hidden');
        invoice_box.eq(1).removeClass('hidden');
    }

    // 修改发票
    $('.bill_mod').on('click', function(){
        var _tp = $('.invoice_bill_type .bill_type').text();
        var _type = _tp == '培训费' ? 1 : 2;
        $('#invoice_type').val(_type);
        var _tit = $('.bill_notice').text();
        $('#invoice_head').val(_tit);

        invoice_box.eq(1).addClass('hidden');
        invoice_box.eq(0).removeClass('hidden');
    });

    // 保存发票
    $('body').on('click', '.bill_save', function(){
        var _tp = $('#invoice_type').val(),
            _tit = $('#invoice_head').val();
        _tp = _tp == 0 ? 1 : _tp;
        if($.trim(_tit) == ''){
            $('#bill_err').show();
            return false;
        }else{
            $('#bill_err').hide();
        }
        var _type = _tp == 1 ? '培训费' : '资料费';
        $('.invoice_bill_type .bill_type').text(_type);
        $('.bill_notice').text(_tit);

        invoice_box.eq(0).addClass('hidden');
        invoice_box.eq(1).removeClass('hidden');
        $('.bill_checked').prop('checked', true);
        $('.express_title, .order_address').show();

    });

    // 发票复选框
    $('body').off('click', '.bill_checked').on('click', '.bill_checked', function(){
        var pay2 = $('#pay_type_200000');
        var that = $(this);
        // 如果已选发票则显示收获地址
        if(this.checked){
            $('.express_title, .order_address').show();
        }else{
            // 如果支付方式为货到付款，则显示收货地址，否则隐藏收货地址
            if(pay2.hasClass('current')){
                $('.express_title, .order_address').show();
            }else{
                $('.express_title, .order_address').hide();
            }
        }
    });

    // 代金卡
    $('body').off('click', '.table_card2 input[name="data[coupon][]"]').on('click', '.table_card2 input[name="data[coupon][]"]', function(){
        var that = $(this),
            list = $('.table_card input[name="data[coupon][]"]');
        var _card = Number(that.attr('price'));
        var _price = price.course;


        if(price.card > (price.course * 0.1)){
            list.each(function(){
                if(!this.checked){
                    $(this).attr({
                        readonly : true,
                        disable : true
                    });
                }
            });
            
            return false;
        }else{     
            list.not(':checked').attr({
                readonly : false,
                disable : false
            });
        }

        if(this.checked){
            price.card += _card;
            
        }else{
            price.card -= _card;
            
        }   

        

        price.course = price.course - price.card;
        $('.money').text('￥'+ price.course);
        console.log(price.card);
    });

})();


function setAllPrice(){
    var paytpl = '课程总金额：￥$course$.00 + 快递费：￥$express$.00 - 帐户余额：￥$balance$.00 = 您需支付：<strong>￥$pay$.00</strong><input value="20" id="carriage_hidden" type="hidden">'
    var box  = $('.all_money');
    var _html = paytpl.replace('$course$', price.course);
        _html = _html.replace('$express$', price.express);
        _html = _html.replace('$balance$', price.balance);

        price.pay = Number(price.course) + Number(price.express) - Number(price.balance);

        _html = _html.replace('$pay$', Number(price.pay));

    box.html(_html);
}

function getCoursePrice(){
    var course_price = $('.money').text();
    course_price = course_price.replace('￥','');
    price.course = Number(course_price);
    return price.course;
}
/*
 * 省市区联动
 */
// function renderAreaSelect () {
//     var defaults = {
//         s1:'add_province',
//         s2:'add_city',
//         s3:'add_country',
//         v1:$("#add_province").val(),
//         v2:$("#add_city").val(),
//         v3:$("#add_country").val()
//     };
//     $('#add_province').empty('');
//     threeSelect(defaults); 
// };

/**
 * [updateAddress description]
 * @param  {[type]} id [description]
 * @return {[type]}    [description]
 *
 *  value="100372"
    data-username="李丽" 
    data-province="1" 
    data-city="1" 
    data-county="8" 
    data-area="北京市市辖区海淀区" 
    data-address="北京市海淀区中关村大街32号和盛大厦808" 
    data-zipcode="100010" 
    data-phone="15110217302" 
 */
function updateAddress(id){
    var box = $('#addid_' + id);
    if(box.length == 0){ return ; }

    box.prop('checked', true);

    var data = box.data();
    var inputs = $(addressInput);
    renderAreaSelect();

    inputs.each(function(){
        var _id = this.id;
            _id = _id.replace('add_','');

        if(this.id == 'add_province' || this.id == 'add_city' || this.id == 'add_country'){

            $(this).find('option[value="' + data[_id] + '"]').prop('selected', true);
            
            $('#' + _id).val(data[_id]);

            // setTimeout(function(){
            //     renderAreaSelect();
            // }, 200);
        }else{
            $(this).val(data[_id]);
        }
    });
    renderAreaSelect();
 
    $('#add_id').val(id);
    var newAddress = $('#details-form');
    newAddress.show();
}

function saveNewAddress(inputs){
    var input = inputs || $(addressInput);
    var data = { id : 0 };
    data.id = $('#add_id').val();

    var id;
    inputs.each(function(){
        id = this.id;
        id = id.replace('add_', '');
        data[id] = $(this).val();
    });

    data['province_text'] = $('#add_province option:checked').text();
    data['city_text'] = $('#add_city option:checked').text();
    data['country_text'] = $('#add_country option:checked').text();

    var _tpl = '<li>'
                    +'  <input type="radio" '
                    +'      data-phone="$phone$" '
                    +'      data-zipcode="$zipcode$" '
                    +'      data-address="$address$" '
                    +'      data-area="$province_text$ $city_text$ $country_text$" '
                    +'      data-county="$country$" '
                    +'      data-city="$city$" '
                    +'      data-province="$province$" '
                    +'      data-realname="$realname$" '
                    +'      value="$id$" '
                    +'      name="data[addid]" '
                    +'      id="addid_$id$" checked=true'
                    +'  />'
                    +'  <span>$realname$</span>，<span>$province_text$ $city_text$ $country_text$</span>'
                    +'  <span>$address$</span>，'
                    +'  <span>$zipcode$</span>，'
                    +'  <span>$phone$</span>'
                    +'  【<a href="javascript:updateAddress($id$);">修改</a>】'
                    +'</li>';

    var o = {
        id : data.id,
        realname : data.realname,
        province_id : data.province,
        city_id : data.city,
        country_id : data.country,
        address : data.address,
        zipcode : data.zipcode,
        phone : data.phone
    };

    $.ajax({
        url : '/shoppingCart/saveStuAdds',
        type: 'POST',
        dataType:'json',
        data : o,
        success:function(result){
            if(!result.sign){
                return;
            }
            var _id = result.addId;
            var tp = _tpl;
            tp = tp.replace(/\$id\$/g, _id);
            tp = tp.replace(/\$phone\$/g, data.phone);
            tp = tp.replace(/\$zipcode\$/g, data.zipcode);
            tp = tp.replace(/\$address\$/g, data.address);
            tp = tp.replace(/\$country\$/g, data.country);
            tp = tp.replace(/\$city\$/g, data.city);
            tp = tp.replace(/\$province\$/g, data.province);
            tp = tp.replace(/\$realname\$/g, data.realname);
            tp = tp.replace(/\$province_text\$/g, data.province_text);
            tp = tp.replace(/\$city_text\$/g, data.city_text);
            tp = tp.replace(/\$country_text\$/g, data.country_text);
        
            if(result.type === 1){
                $(tp).prependTo('.address_list ul');
            }else if(result.type === 2){
                $('#addid_'+data.id).parent().html(tp);
            }

            $('.info_from').hide();
         
        }
    });
    // var addressInput = '#realname, #province, #city, #country, #address, #zipcode, #phone';

    // id=0&realname=啊啊&province_id=1&city_id=1&country_id=1&address=阿德法撒旦法阿斯蒂芬阿斯&zipcode=100000&phone=13912345678
}
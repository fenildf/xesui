/**
 * XESUI 
 * Copyright 2013 xueersi.com All rights reserved.
 *
 * @description 
 *
 * @author Marco (marco@xesui.com)
 * @modify 2013-07-17 13:39:17
 * @version $Id$
 * 
 * @links http://xesui.com
 */


/**
 * @name 
 * @description 
 * 
 * @module 
 * @submodule 
 * @main 
 * @class 
 * @constructor 
 * @static 
 */

$(function(){

    // 金币换礼
    $('.layout').off('mouseover', '.gift-item img').on('mouseover', '.gift-item img', function(){
        var that = $(this).parents('.gift-item'),
            html = that.find('dl.biggift').clone(),
            wrap = $('<div></div>');
            html.show();
            wrap.html(html);

        var size = {
            w : that.outerWidth(),
            h : that.outerHeight(),
            l : that.offset().left,
            t : that.offset().top
        };
        var left = Number(size.l + size.w) > Number($(window).width() / 2) ? (size.l - size.w - 170) : (size.l + size.w);
        var arrow = Number(size.l + size.w) > Number($(window).width() / 2) ? 'rt' : 'lt';

        var opt = {
            id    : 'gift',
            cls   : 'dialog_gift',
            title : false,
            close : false,
            submit: false,
            cancel: false,
            lock  : false,
            left  : left,
            top   : size.t,
            arrow : arrow,
            content : wrap.html()
        };

        xue.win(opt);

        that.on('mouseout', function(){
            xue.win('gift').close();
        });

    });
});